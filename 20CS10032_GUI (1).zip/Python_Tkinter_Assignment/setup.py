import setuptools
from os.path import dirname, join
current_dir = dirname(__file__)
file_path = join(current_dir, "./data/README.md")
with open(file_path, "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="my_package_20CS10032",
    version="0.0.1",
    author="Kunchala Chandra Sekhara Azad",
    author_email="azadnrt2002@gmail.com",
    description="Python DS Lab Assignment, IIT KGP [Spring 2022]",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.9',
)