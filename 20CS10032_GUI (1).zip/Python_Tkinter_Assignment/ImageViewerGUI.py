####### REQUIRED IMPORTS FROM THE PREVIOUS ASSIGNMENT #######
from my_package.model import InstanceSegmentationModel
from my_package.data.dataset import Dataset
from my_package.analysis.visualize import plot_visualization
from PIL import Image
####### ADD THE ADDITIONAL IMPORTS FOR THIS ASSIGNMENT HERE #######
from tkinter import *
from cv2 import cv2 as cv
import os
from functools import partial
from PIL import ImageTk, Image
from tkinter import filedialog

# Define the function you want to call when the filebrowser button is clicked.
def fileClick(clicked, dataset, segmentor):

	####### CODE REQUIRED (START) #######
	# This function should pop-up a dialog for the user to select an input image file.
	# Once the image is selected by the user, it should automatically get the corresponding outputs from the segmentor.
	# Hint: Call the segmentor from here, then compute the output images from using the `plot_visualization` function and save it as an image.
	# Once the output is computed it should be shown automatically based on choice the dropdown button is at.
	# To have a better clarity, please check out the sample video.
	global  my_image
	root.filename = filedialog.askopenfilename(initialdir="C:/Users/venka/Desktop/sem4@kgp/software Engi. lab/asgn 3/CS29006_SW_Lab_Spr2022-master/Python_GUI_Assignment/Python_Tkinter_Assignment/data/imgs", title="Select a file", filetypes=[("jpg files", "*.jpg")])
	index=int(os.path.basename(root.filename)[0])
	e.delete(0,5)
	e.insert(0,str(index)+".jpg")
	my_image = ImageTk.PhotoImage(Image.open(root.filename).resize((500,250)))
	
	pred_boxes, pred_masks, pred_class, pred_score = segmentor(dataset[index]['image'])
	plot_visualization(root,clicked,dataset[index]['image'] , pred_boxes, pred_score, pred_masks, r"C:/Users/venka/Desktop/sem4@kgp/software Engi. lab/asgn 3/CS29006_SW_Lab_Spr2022-master/Python_GUI_Assignment/Python_Tkinter_Assignment/output/")
	
	
	
	####### CODE REQUIRED (END) #######

# `process` function definition starts from here.
# will process the output when clicked.


def process(clicked):

	####### CODE REQUIRED (START) #######
	# Should show the corresponding segmentation or bounding boxes over the input image wrt the choice provided.
	# Note: this function will just show the output, which should have been already computed in the `fileClick` function above.
	# Note: also you should handle the case if the user clicks on the `Process` button without selecting any image file.
	
	if e.get()=="" :
		print("Select a file first!")
	else :
		my_image_label = Label(root,image=my_image)
		global img
		Path=r"C:\Users\venka\Desktop\sem4@kgp\software Engi. lab\asgn 3\CS29006_SW_Lab_Spr2022-master\Python_GUI_Assignment\Python_Tkinter_Assignment\output\mod_img.png"
		img=ImageTk.PhotoImage(Image.fromarray(cv.imread(Path)).resize((500,250)))
		my_img_label = Label(root,image=img)
		my_image_label.grid(row=2, column=0)
		my_img_label.grid(row=2, column=1)	
	####### CODE REQUIRED (END) #######


# `main` function definition starts from here.
if __name__ == '__main__':

	# CODE REQUIRED (START) ####### (2 lines)
	# Instantiate the root window.
	# Provide a title to the root window.
	global root
	root = Tk()
	root.title('GUI Lab assignment')

	####### CODE REQUIRED (END) #######

	# Setting up the segmentor model.
	annotation_file = './data/annotations.jsonl'
	transforms = []

	# Instantiate the segmentor model.
	segmentor = InstanceSegmentationModel()
	# Instantiate the dataset.
	dataset = Dataset(annotation_file, transforms=transforms)

	# Declare the options.
	options = ["Segmentation", "Bounding-box"]
	clicked = StringVar()
	clicked.set(options[0])

	e = Entry(root, width=70)
	e.grid(row=0, column=0)

	####### CODE REQUIRED (START) #######
	# Declare the file browsing button
	my_btn = Button(root, text="...",command= partial(fileClick,clicked,dataset,segmentor))
	my_btn.grid(row=0, column=1)

	####### CODE REQUIRED (END) #######

	####### CODE REQUIRED (START) #######
	# Declare the drop-down button
	drop = OptionMenu(root, clicked, *options)
	drop.grid(row=0, column=2)
	####### CODE REQUIRED (END) #######

	# This is a `Process` button, check out the sample video to know about its functionality
	myButton = Button(root, text="Process", command=partial(process,clicked))
	myButton.grid(row=0, column=3)

	frame=Frame(root)
	frame.grid(row=1,column=0)
	
	# CODE REQUIRED (START) ####### (1 line)
	# Execute with mainloop()
	
	root.mainloop()
	####### CODE REQUIRED (END) #######
