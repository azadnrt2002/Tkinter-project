# Imports
import random
from cv2 import cv2 as cv
import os
from PIL import Image
from tkinter import *
from PIL import ImageTk, Image

# Write the required arguments
def plot_visualization(root,clicked, img, pred_boxes, pred_scores, pred_masks, output):

  # The function should plot the predicted segmentation maps and the bounding boxes on the images and save them.
  # Tip: keep the dimensions of the output image less than 800 to avoid RAM crashes.
  b = pred_scores[:]
  indices = []
  img = img.transpose(1, 2, 0)
  img = img*255.0
  for i in range(min(3, len(pred_scores))):
    max_index = b.index(max(b))
    indices.append(max_index)
    b[max_index] = -1
  
  x=[1.0,0.0,0.0]
  y=[0.0,1.0,0.0]
  z=[0.0,0.0,1.0]

  if clicked.get() == "Segmentation":
        for i in indices:
         masks = pred_masks[i][0]*255.0
         bbox = pred_boxes[i]
         for j in range(int(bbox[0][0]), int(bbox[1][0])):
          for k in range(int(bbox[0][1]), int(bbox[1][1])):
           if masks[k][j] >=250:
            img[k][j] = (img[k][j][0]*x[i], img[k][j][1]*y[i], img[k][j][2]*z[i])
  
  else :
        for i in indices:
         bbox = pred_boxes[i]
         org = (int(bbox[0][0]), int(bbox[0][1]))
         dim = (int(bbox[1][0]), int(bbox[1][1]))
         cv.rectangle(img, org, dim, (x[i]*255.0, y[i]*255.0, z[i]*255.0), 1)
  os.chdir(output)
  
  cv.imwrite("mod_img.png", img)
  Path=r"C:\Users\venka\Desktop\sem4@kgp\software Engi. lab\asgn 3\CS29006_SW_Lab_Spr2022-master\Python_GUI_Assignment\Python_Tkinter_Assignment\output\mod_img.png"
  global new_img
  new_img=ImageTk.PhotoImage(Image.fromarray(cv.imread(Path)).resize((500,250)))
  my_img_label = Label(root,image=new_img)
  my_img_label.grid(row=1,column=0)
  